<?php
	$this->print_msg("<b>Note:</b> Please visit the <a href=\"admin.php?target=payment_method&payment_method=asiapayclientpost\">Payment method setup page</a> in order to setup your AsiaPay Merchant Account");
?>